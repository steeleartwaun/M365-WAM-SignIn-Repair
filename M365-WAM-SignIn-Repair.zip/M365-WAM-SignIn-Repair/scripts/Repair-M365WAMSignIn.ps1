<#
.SYNOPSIS
    Repairs Microsoft 365 / Office / AAD / WAM sign-in issues for a specific Citrix or RDS user session.

.DESCRIPTION
    This script is designed for multi-user Windows Server environments such as Citrix or RDS.
    It safely targets one user session by Session ID, stops only that user's Office/Teams processes,
    and renames common Microsoft identity cache folders and registry keys.

    Use this when users experience:
    - Repeated Microsoft 365 sign-in prompts
    - Outlook/Office authentication loops
    - Teams sign-in failures
    - OneDrive authentication issues
    - AAD/WAM token cache corruption
    - Office apps unable to complete MFA or modern authentication

.NOTES
    Author: Artwaun Steele
    Version: 1.0.0
    Requires: PowerShell running as Administrator on the Citrix/RDS server
    Scope: Per-user session repair
#>

[CmdletBinding(SupportsShouldProcess = $true)]
param (
    [Parameter(Mandatory = $true)]
    [string]$UserName,

    [Parameter(Mandatory = $true)]
    [int]$SessionID,

    [Parameter(Mandatory = $true)]
    [string]$UserSID,

    [Parameter(Mandatory = $false)]
    [string]$UserProfilePath = "C:\Users\$UserName",

    [Parameter(Mandatory = $false)]
    [switch]$SkipRegistryRepair
)

$ErrorActionPreference = "Continue"
$Stamp = Get-Date -Format "yyyyMMddHHmmss"
$UserLocal = Join-Path $UserProfilePath "AppData\Local"

Write-Host ""
Write-Host "Microsoft 365 / AAD / WAM Sign-In Repair" -ForegroundColor Cyan
Write-Host "Target User: $UserName" -ForegroundColor Cyan
Write-Host "Session ID : $SessionID" -ForegroundColor Cyan
Write-Host "User SID   : $UserSID" -ForegroundColor Cyan
Write-Host "Profile    : $UserProfilePath" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Path $UserProfilePath)) {
    Write-Warning "User profile path was not found: $UserProfilePath"
    Write-Warning "Verify the username/profile path before continuing."
}

$OfficeProcesses = @(
    "OUTLOOK",
    "WINWORD",
    "EXCEL",
    "POWERPNT",
    "ONENOTE",
    "MSACCESS",
    "Teams",
    "ms-teams"
)

Write-Host "Stopping Office/Teams processes for $UserName in Session $SessionID only..." -ForegroundColor Yellow

$TargetProcesses = Get-Process -ErrorAction SilentlyContinue |
    Where-Object {
        $_.SessionId -eq $SessionID -and
        $_.ProcessName -in $OfficeProcesses
    }

if ($TargetProcesses) {
    foreach ($Process in $TargetProcesses) {
        if ($PSCmdlet.ShouldProcess("$($Process.ProcessName) PID $($Process.Id)", "Stop process")) {
            Write-Host "Stopping $($Process.ProcessName) PID $($Process.Id) Session $($Process.SessionId)" -ForegroundColor Cyan
            Stop-Process -Id $Process.Id -Force -ErrorAction SilentlyContinue
        }
    }
}
else {
    Write-Host "No matching Office/Teams processes found in Session $SessionID." -ForegroundColor DarkGray
}

Write-Host ""
Write-Host "Renaming local AAD/WAM cache folders..." -ForegroundColor Yellow

$CachePaths = @(
    "$UserLocal\Microsoft\IdentityCache",
    "$UserLocal\Microsoft\OneAuth",
    "$UserLocal\Microsoft\TokenBroker",
    "$UserLocal\Packages\Microsoft.AAD.BrokerPlugin_cw5n1h2txyewy",
    "$UserLocal\Packages\Microsoft.Windows.CloudExperienceHost_cw5n1h2txyewy"
)

foreach ($Path in $CachePaths) {
    if (Test-Path $Path) {
        $NewName = "$(Split-Path $Path -Leaf).old_$Stamp"

        if ($PSCmdlet.ShouldProcess($Path, "Rename to $NewName")) {
            Rename-Item -Path $Path -NewName $NewName -ErrorAction SilentlyContinue
            Write-Host "Renamed: $Path" -ForegroundColor Green
        }
    }
    else {
        Write-Host "Not found: $Path" -ForegroundColor DarkGray
    }
}

if (-not $SkipRegistryRepair) {
    Write-Host ""
    Write-Host "Renaming AAD/WAM registry keys..." -ForegroundColor Yellow

    $RegPaths = @(
        "Registry::HKEY_USERS\$UserSID\SOFTWARE\Microsoft\IdentityCRL",
        "Registry::HKEY_USERS\$UserSID\SOFTWARE\Microsoft\Windows\CurrentVersion\AAD",
        "Registry::HKEY_USERS\$UserSID\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WorkplaceJoin"
    )

    foreach ($RegPath in $RegPaths) {
        if (Test-Path $RegPath) {
            $KeyName = Split-Path $RegPath -Leaf
            $NewKeyName = "$KeyName.old_$Stamp"

            if ($PSCmdlet.ShouldProcess($RegPath, "Rename registry key to $NewKeyName")) {
                Rename-Item -Path $RegPath -NewName $NewKeyName -ErrorAction SilentlyContinue
                Write-Host "Renamed registry key: $RegPath" -ForegroundColor Green
            }
        }
        else {
            Write-Host "Registry key not found: $RegPath" -ForegroundColor DarkGray
        }
    }
}
else {
    Write-Host ""
    Write-Host "Registry repair skipped by parameter." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Completed successfully." -ForegroundColor Green
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "1. Fully log the user out of Citrix/RDS. Do not only disconnect the session." -ForegroundColor Yellow
Write-Host "2. Have the user sign back in." -ForegroundColor Yellow
Write-Host "3. Open Outlook, Teams, OneDrive, or Office and allow reauthentication." -ForegroundColor Yellow
Write-Host ""
