# Troubleshooting Notes

## Scenario

A user inside a Citrix environment was repeatedly prompted to sign in to Microsoft 365 applications. Office authentication was not completing successfully.

## Suspected Cause

Corrupted Microsoft identity cache or WAM/AAD token data inside the affected user's Windows profile.

## Troubleshooting Logic

1. Confirm the issue is isolated to the user/session.
2. Identify the user's Citrix/RDS session ID.
3. Stop only that user's Office and Teams processes.
4. Rename Microsoft identity cache folders.
5. Rename user-specific AAD/WAM registry keys.
6. Fully log the user out of Citrix/RDS.
7. Have the user sign back in and reauthenticate.

## Why Rename Instead Of Delete?

Renaming preserves the original data for rollback while forcing Windows and Microsoft 365 apps to recreate clean authentication cache data.

## Key Paths

Local profile cache paths:

```text
AppData\Local\Microsoft\IdentityCache
AppData\Local\Microsoft\OneAuth
AppData\Local\Microsoft\TokenBroker
AppData\Local\Packages\Microsoft.AAD.BrokerPlugin_cw5n1h2txyewy
AppData\Local\Packages\Microsoft.Windows.CloudExperienceHost_cw5n1h2txyewy
```

Registry paths:

```text
HKEY_USERS\<UserSID>\SOFTWARE\Microsoft\IdentityCRL
HKEY_USERS\<UserSID>\SOFTWARE\Microsoft\Windows\CurrentVersion\AAD
HKEY_USERS\<UserSID>\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WorkplaceJoin
```

## Interview Talking Point

"I built a PowerShell remediation script for Microsoft 365 sign-in issues in Citrix. The script safely targets a single user session by Session ID, stops only that user's Office processes, renames AAD/WAM identity cache folders and registry keys, then forces clean reauthentication after a full logoff. I designed it to be safer for multi-user environments by avoiding broad process termination."
