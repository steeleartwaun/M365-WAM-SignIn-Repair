# Changelog

## 1.0.0

- Initial GitHub-ready release.
- Added parameterized PowerShell script.
- Added Citrix/RDS session-safe process targeting.
- Added AAD/WAM cache folder rename logic.
- Added per-user registry key rename logic.
- Added README and troubleshooting notes.
