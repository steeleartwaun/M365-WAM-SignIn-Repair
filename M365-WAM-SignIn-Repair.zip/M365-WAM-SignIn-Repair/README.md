# Microsoft 365 WAM Sign-In Repair

PowerShell remediation script for Microsoft 365, Office, Azure AD/Entra ID, and WAM authentication issues in Citrix or RDS environments.

This project is based on a real-world endpoint support scenario where a user experienced Office/Microsoft 365 sign-in problems inside a Citrix session. The original fix targeted the user session, renamed broken identity cache folders, and reset AAD/WAM-related registry keys. 

## What This Fixes

This script can help remediate:

- Repeated Microsoft 365 sign-in prompts
- Outlook authentication loops
- Teams sign-in failures
- OneDrive authentication problems
- Office apps failing modern authentication
- AAD/WAM token cache corruption
- Broken user identity cache inside Citrix/RDS sessions

## Why This Script Is Citrix-Safe

In shared server environments, you should not blindly kill Office processes for every user.

This script targets a specific:

- Username
- Session ID
- User SID
- User profile path

It stops only Office/Teams processes running inside the affected user's session.

## Repository Structure

```text
M365-WAM-SignIn-Repair/
├── scripts/
│   └── Repair-M365WAMSignIn.ps1
├── docs/
│   └── troubleshooting-notes.md
├── .gitignore
├── LICENSE
└── README.md
```

## Prerequisites

Run PowerShell as Administrator on the Citrix/RDS server.

You need:

- Affected username
- Citrix/RDS session ID
- User SID
- User profile path if it differs from `C:\Users\username`

## How To Find Session ID

From Command Prompt or PowerShell:

```powershell
query user
```

Example output:

```text
USERNAME        SESSIONNAME        ID  STATE
jsmith          rdp-tcp#55          3   Active
```

In this example, the Session ID is `3`.

## How To Find User SID

```powershell
wmic useraccount where name='username' get sid
```

Or:

```powershell
Get-ADUser username -Properties SID | Select-Object Name,SID
```

## Usage

```powershell
.\scripts\Repair-M365WAMSignIn.ps1 `
    -UserName "username" `
    -SessionID 3 `
    -UserSID "S-1-5-21-xxxxxxxxxx-xxxxxxxxxx-xxxxxxxxxx-xxxx"
```

Optional custom profile path:

```powershell
.\scripts\Repair-M365WAMSignIn.ps1 `
    -UserName "username" `
    -SessionID 3 `
    -UserSID "S-1-5-21-xxxxxxxxxx-xxxxxxxxxx-xxxxxxxxxx-xxxx" `
    -UserProfilePath "C:\Users\username"
```

Dry run with `-WhatIf`:

```powershell
.\scripts\Repair-M365WAMSignIn.ps1 `
    -UserName "username" `
    -SessionID 3 `
    -UserSID "S-1-5-21-xxxxxxxxxx-xxxxxxxxxx-xxxxxxxxxx-xxxx" `
    -WhatIf
```

Skip registry repair:

```powershell
.\scripts\Repair-M365WAMSignIn.ps1 `
    -UserName "username" `
    -SessionID 3 `
    -UserSID "S-1-5-21-xxxxxxxxxx-xxxxxxxxxx-xxxxxxxxxx-xxxx" `
    -SkipRegistryRepair
```

## What The Script Does

### 1. Stops Office/Teams Processes For One Session

Stops only the affected user's processes:

- Outlook
- Word
- Excel
- PowerPoint
- OneNote
- Access
- Teams

### 2. Renames Local Identity Cache Folders

Renames common Microsoft authentication cache folders:

- `IdentityCache`
- `OneAuth`
- `TokenBroker`
- `Microsoft.AAD.BrokerPlugin`
- `Microsoft.Windows.CloudExperienceHost`

The folders are renamed with a timestamp instead of deleted.

### 3. Renames AAD/WAM Registry Keys

Renames per-user registry keys related to identity and workplace join:

- `IdentityCRL`
- `AAD`
- `WorkplaceJoin`

### 4. Forces Fresh Authentication

After the user fully logs out and back in, Microsoft 365 apps rebuild identity cache and prompt for fresh authentication.

## Important Notes

Do not only disconnect the Citrix session. Fully log the user out.

This script renames cache folders and registry keys instead of deleting them, which provides a rollback path.

Test in a non-production environment when possible.

## When To Use

Use this when normal fixes do not resolve the issue, such as:

- Rebuilding Outlook profile
- Clearing browser cache
- Resetting MFA
- Restarting Teams
- Rebooting the endpoint/session host

## When Not To Use

Do not use this as a first step for every Microsoft 365 issue.

Do not use this without confirming the correct user session and SID.

Do not run this broadly against all users on a Citrix server.

## Skills Demonstrated

This project demonstrates:

- PowerShell troubleshooting
- Citrix/RDS session-safe process handling
- Microsoft 365 authentication troubleshooting
- Entra ID/AAD identity cache remediation
- Endpoint support
- Tier 2 systems administration
- User profile and registry troubleshooting

## Author

Artwaun Steele
